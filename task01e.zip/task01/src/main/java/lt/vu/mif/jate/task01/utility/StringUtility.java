package lt.vu.mif.jate.task01.utility;

public class StringUtility {

    public static String reverse(String s) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
